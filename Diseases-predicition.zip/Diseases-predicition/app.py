import pickle
import streamlit as st

from utils import symptoms, encodings

with open('best_model.pkl', 'rb') as f:
    model = pickle.load(f)


st.title('Disease Prediction')

selections=st.multiselect(label="choose symptom", options=symptoms)

if st.button('Predict'):
    values = [ 1 if symptom in selections else 0 for symptom in symptoms]

    prediction = model.predict([values])

    st.write('Prediction: ', encodings.get(prediction[0]))

